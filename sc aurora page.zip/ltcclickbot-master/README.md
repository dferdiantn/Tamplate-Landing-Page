# Link LTCClickBot Telegram
Hargai Refferal : https://t.me/Litecoin_click_bot?start=IT3x

# Cara Install 
$ pkg update && pkg upgrade<br>
$ pkg install python git unzip<br>
$ git clone https://github.com/kyo1337/ltcclickbot<br>
$ cd ltcclickbot<br>
$ pip3 install -r requirements.txt<br>
$ python3 main.py phone_number<br>

# Note :
- Bisa Menggunakan Nomor Luar/ID, Syarat Input Nomor : python main.py 62813****** / python main.py 1315*******
- Input OTP
- And Happy Mining

# Media Sosial :
- https://linktr.ee/doko1554

# Special Thx :
Jejaka Tutorial
